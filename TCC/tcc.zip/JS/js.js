/*CRIA AS MASCARAS*/
$(document).ready(function(){
    $('#cpf').mask('000.000.000-00');
    $('#dt_nasc').mask('00/00/0000');        
    $('#tell').mask('(99)9-9999.9999');
});

