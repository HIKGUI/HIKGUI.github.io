<?php

    //FAX CONEXÃO COM O BANCO DE DADOS
    
            $servername = "localhost";
            $username = "id19204052_adm";
            $password = "Guilherme1414.";
            $dbname = "id19204052_tcc_barbearia";

            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            
            
?>